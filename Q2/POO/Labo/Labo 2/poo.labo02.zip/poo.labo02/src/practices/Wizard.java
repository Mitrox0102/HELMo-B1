package practices;

public class Wizard {
  // TODO: définir ce qu'est un sorcier

}
