package practices;

public class SpellTest {
  // TODO : valider le reste de la classe Spell
}
