package practices;

public class SpellPracticeSessionTest {
  // TODO : valider la classe SpellPracticeSession
}
