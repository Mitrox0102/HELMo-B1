package practices;

public class Spell {
  // TODO: définir ce qu'est un sortilège
}
