package tcg;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class RestoreTest {

    @Test
    void should_restore_no_cards_when_not_needed() {
        TCGCard dragon = TCGCardSample.makeDragonCard();
        TCGCard stoneGolem =TCGCardSample.makeStoneGolemCard();        
        TCGCard[] deck = {dragon, stoneGolem};
        
        int[] result = TCGCardApp.restore(deck, 2);

        assertEquals(0, result[0]); // HP count
        assertEquals(0, result[1]); // MP count
    }

    @Test
    void should_restore_when_hp_xor_mp_is_not_enough() {
        TCGCard royalKnight = TCGCardSample.makeRoyalKnightCard();
        TCGCard werewolf = TCGCardSample.makeWerewolfCard();
        royalKnight.setHealthPoints(0); // Dead
        werewolf.setHealthPoints(90);
        werewolf.setManaPoints(1); // Need mana refill
        TCGCard[] deck = {royalKnight, werewolf};
        
        int[] result = TCGCardApp.restore(deck, 2);

        assertEquals(1, result[0]); // HP count
        assertEquals(1, result[1]); // MP count
    }

    @Test
    void should_restore_when_hp_or_mp_are_note_enough() {
        TCGCard royalKnight = TCGCardSample.makeRoyalKnightCard();
        TCGCard werewolf = TCGCardSample.makeWerewolfCard();
        TCGCard shadowMage = TCGCardSample.makeShadowMageCard();
        TCGCard phoenix =TCGCardSample.makePhoenixCard();
        shadowMage.setHealthPoints(0);
        shadowMage.setManaPoints(1);
        phoenix.setHealthPoints(0);
        phoenix.setManaPoints(1);
        
        TCGCard[] deck = {royalKnight, shadowMage, werewolf, phoenix};
        
        int[] result = TCGCardApp.restore(deck, 4);

        assertEquals(2, result[0]); // HP count
        assertEquals(2, result[1]); // MP count
    }
}

