package lecon04;

import java.util.Arrays;

/**
 * @author Adapté de Christiane Mathy
 */
public class GrilleLotto {
	private final int nbBoules;
	private final int tailleGrille;
	private int[] grille; // numéros tirés
	private int nbreTiragesEffectues;

	public GrilleLotto(int nbBoules, int tailleGrille) {
		this.nbBoules = Math.max(2, nbBoules);
		this.tailleGrille = Math.max(1, tailleGrille);
		this.grille = new int[tailleGrille];
		this.nbreTiragesEffectues = 0;
	}
	
	public void tirageGrille() {
		this.nbreTiragesEffectues = 0;
		for(int i = 0; i < tailleGrille; i++) {
			tirageBoule(); 
		}
	}
	
	public int[] getGrille() {
		return Arrays.copyOf(grille, tailleGrille);
	}
	
	private boolean numéroUnique (int numéro) {
		for (int indiceTirage=0; indiceTirage < nbreTiragesEffectues; indiceTirage++)
			if (this.grille[indiceTirage] == numéro) {
				return false;
			}

		return true;
	}
	
	private int tirageBoule() { // utilise numéro_unique()
		int n;
		do {
			n = 1 + ((int)(Math.random() * nbBoules)); // n dans[1,42] 
		} while (!numéroUnique(n)) ;

		// mise à jour de la grille
		this.grille[nbreTiragesEffectues] = n;
		nbreTiragesEffectues += 1;

		return n;
	}
}

