package tcg;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

/**
 * Cette classe valide et documente la classe TCGCard
 *
 * @see tcg.TCGCard
 */
class TCGCardTest {

  // Constructeur
  @Test
  @DisplayName("should_create_card_when_valid_parameters_provided")
  void should_create_card_when_valid_parameters_provided() {
    TCGCard card = new TCGCard("Dragon", "Un dragon puissant", 100, 50, 8, 6);

    assertEquals("Dragon", card.getName());
    assertEquals("Un dragon puissant", card.getText());
    assertEquals(100, card.getHealthPoints());
    assertEquals(100, card.getMaxHealthPoints());
    assertEquals(50, card.getManaPoints());
    assertEquals(50, card.getMaxManaPoints());
    assertEquals(8, card.getAttack());
    assertEquals(6, card.getDefense());
  }

  // Validation du nom
  @Test
  @DisplayName("should_throw_exception_when_name_is_null")
  void should_throw_exception_when_name_is_null() {
    assertThrows(IllegalArgumentException.class,
        () -> new TCGCard(null, "Un dragon puissant", 100, 50, 8, 6));
  }

  @Test
  @DisplayName("should_throw_exception_when_text_is_null")
  void should_throw_exception_when_text_is_null() {
    assertThrows(IllegalArgumentException.class,
        () -> new TCGCard("Dragon", null, 100, 50, 8, 6));
  }

  @ParameterizedTest
  @ValueSource(strings = {
      "", " "
  })
  @DisplayName("should_throw_exception_when_name_is_empty_or_blank")
  void should_throw_exception_when_name_is_empty_or_blank(String invalidName) {
    assertThrows(IllegalArgumentException.class,
        () -> new TCGCard(invalidName, "Un dragon puissant", 100, 50, 8, 6));
  }

  // Validation de la description
  @ParameterizedTest
  @ValueSource(strings = {
      "", " "
  })
  @DisplayName("should_throw_exception_when_text_is_empty_or_blank")
  void should_throw_exception_when_text_is_empty_or_blank(String invalidText) {
    assertThrows(IllegalArgumentException.class,
        () -> new TCGCard("Dragon", invalidText, 100, 50, 8, 6));
  }

  // Validation des points de vie
  @ParameterizedTest
  @ValueSource(ints = {
      9, 1000, -1
  })
  @DisplayName("should_throw_exception_when_health_points_are_invalid")
  void should_throw_exception_when_health_points_are_invalid(int invalidHp) {
    assertThrows(IllegalArgumentException.class,
        () -> new TCGCard("Dragon", "Un dragon puissant", invalidHp, 50, 8, 6));
  }

  // Validation des points de mana
  @ParameterizedTest
  @ValueSource(ints = {
      4, 100, -1
  })
  @DisplayName("should_throw_exception_when_mana_points_are_invalid")
  void should_throw_exception_when_mana_points_are_invalid(int invalidMp) {
    assertThrows(IllegalArgumentException.class,
        () -> new TCGCard("Dragon", "Un dragon puissant", 100, invalidMp, 8, 6));
  }

  // Validation de l'attaque
  @ParameterizedTest
  @ValueSource(ints = {
      0, 11, -1
  })
  @DisplayName("should_throw_exception_when_attack_is_invalid")
  void should_throw_exception_when_attack_is_invalid(int invalidAtk) {
    assertThrows(IllegalArgumentException.class,
        () -> new TCGCard("Dragon", "Un dragon puissant", 100, 50, invalidAtk, 6));
  }

  // Validation de la défense
  @ParameterizedTest
  @ValueSource(ints = {
      0, 11, -1
  })
  @DisplayName("should_throw_exception_when_defense_is_invalid")
  void should_throw_exception_when_defense_is_invalid(int invalidDef) {
    assertThrows(IllegalArgumentException.class,
        () -> new TCGCard("Dragon", "Un dragon puissant", 100, 50, 8, invalidDef));
  }

  // Mise à jour des points de vie et de mana
  @Test
  @DisplayName("should_throw_exception_when_setting_invalid_health_points")
  void should_throw_exception_when_setting_invalid_health_points() {
    TCGCard card = new TCGCard("Dragon", "Un dragon puissant", 100, 50, 8, 6);
    assertThrows(IllegalArgumentException.class, () -> card.setHealthPoints(-1));
    assertThrows(IllegalArgumentException.class, () -> card.setHealthPoints(101));
  }

  @Test
  @DisplayName("should_throw_exception_when_setting_invalid_mana_points")
  void should_throw_exception_when_setting_invalid_mana_points() {
    TCGCard card = new TCGCard("Dragon", "Un dragon puissant", 100, 50, 8, 6);
    assertThrows(IllegalArgumentException.class, () -> card.setManaPoints(-1));
    assertThrows(IllegalArgumentException.class, () -> card.setManaPoints(51));
  }

  // Soins et mana
  @Test
  @DisplayName("should_restore_health_to_max_when_heal_called")
  void should_restore_health_to_max_when_heal_called() {
    TCGCard card = new TCGCard("Dragon", "Un dragon puissant", 100, 50, 8, 6);
    card.setHealthPoints(50);
    card.heal();
    assertEquals(100, card.getHealthPoints());
  }

  @Test
  @DisplayName("should_restore_mana_to_max_when_fill_mana_called")
  void should_restore_mana_to_max_when_fill_mana_called() {
    TCGCard card = new TCGCard("Dragon", "Un dragon puissant", 100, 50, 8, 6);
    card.setManaPoints(25);
    card.fillMana();
    assertEquals(50, card.getManaPoints());
  }

  // État de la carte
  @Test
  @DisplayName("should_return_false_when_health_points_are_zero")
  void should_return_false_when_health_points_are_zero() {
    TCGCard card = new TCGCard("Dragon", "Un dragon puissant", 100, 50, 8, 6);
    card.setHealthPoints(0);
    assertFalse(card.isAlive());
  }

  @Test
  @DisplayName("should_return_true_when_health_points_are_above_zero")
  void should_return_true_when_health_points_are_above_zero() {
    TCGCard card = new TCGCard("Dragon", "Un dragon puissant", 100, 50, 8, 6);
    assertTrue(card.isAlive());
  }
}
