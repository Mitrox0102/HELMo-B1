package tcg;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class ApplyDamageTest {


  @Test
  void should_pass_the_happy_path() {
    TCGCard golem = TCGCardSample.makeStoneGolemCard();
    TCGCard knight = TCGCardSample.makeRoyalKnightCard();

    final int expectedDamage = 8;
    final int expectedManaConsumed = 3;
    final int expectedHp = golem.getHealthPoints() - expectedDamage;
    final int expectedMp = knight.getManaPoints() - expectedManaConsumed;

    int actualDamage = TCGCardApp.applyDamage(knight, golem);

    assertEquals(expectedDamage, actualDamage);
    assertEquals(expectedHp, golem.getHealthPoints());
    assertEquals(expectedMp, knight.getManaPoints());
  }

  @Test
  void should_pass_the_happy_path_2() {
    TCGCard werewolf = TCGCardSample.makeWerewolfCard();
    TCGCard mage = TCGCardSample.makeShadowMageCard();

    final int expectedDamage = 18;
    final int expectedManaConsumed = 2;
    final int expectedHp = werewolf.getHealthPoints() - expectedDamage;
    final int expectedMp = mage.getManaPoints() - expectedManaConsumed;

    int actualDamage = TCGCardApp.applyDamage(mage, werewolf);

    assertEquals(expectedDamage, actualDamage);
    assertEquals(expectedHp, werewolf.getHealthPoints());
    assertEquals(expectedMp, mage.getManaPoints());
  }

  @Test
  void should_do_nothing_when_not_enough_mana() {
    TCGCard werewolf = TCGCardSample.makeWerewolfCard();
    TCGCard mage = TCGCardSample.makeShadowMageCard();
    mage.setManaPoints(1);

    final int expectedHp = werewolf.getHealthPoints();
    final int expectedMp = mage.getManaPoints();

    int actualDamage = TCGCardApp.applyDamage(mage, werewolf);

    assertEquals(-1, actualDamage);
    assertEquals(expectedHp, werewolf.getHealthPoints());
    assertEquals(expectedMp, mage.getManaPoints());
  }

  @Test
  void should_kill_the_target_when_hp_is_not_enough() {
    TCGCard werewolf = TCGCardSample.makeWerewolfCard();
    werewolf.setHealthPoints(1);

    TCGCard mage = TCGCardSample.makeShadowMageCard();

    final int expectedDamage = 1;
    final int expectedManaConsumed = 2;
    final int expectedHp = 0;
    final int expectedMp = mage.getManaPoints() - expectedManaConsumed;

    int actualDamage = TCGCardApp.applyDamage(mage, werewolf);

    assertEquals(expectedDamage, actualDamage);
    assertEquals(expectedHp, werewolf.getHealthPoints());
    assertEquals(expectedMp, mage.getManaPoints());
  }

  @Test
  void should_should_cause_no_damage_when_attack_stat_is_not_strong_enough() {
    TCGCard golem = TCGCardSample.makeStoneGolemCard();
    TCGCard phoenix = TCGCardSample.makePhoenixCard();

    final int expectedDamage = 0;
    final int expectedManaConsumed = 2;
    final int expectedHp = golem.getHealthPoints();
    final int expectedMp = phoenix.getManaPoints() - expectedManaConsumed;

    int actualDamage = TCGCardApp.applyDamage(phoenix, golem);

    assertEquals(expectedDamage, actualDamage);
    assertEquals(expectedHp, golem.getHealthPoints());
    assertEquals(expectedMp, phoenix.getManaPoints());
  }

}
