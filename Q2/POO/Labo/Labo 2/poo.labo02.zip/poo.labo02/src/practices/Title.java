package practices;

/**
 * Définit le titre qu'un sorcier peut avoir.
 * <p>
 * Vous ne pouvez pas créer de nouveaux objets avec cette classe. En revanche, vous pouvez utiliser
 * les constantes Title.STUDENT, Title.HEADMASTER, etc.
 * </p>
 */
public class Title {
  private static final String HEADMASTER_NAME = "Headmaster";
  private static final String PROFESSOR_NAME = "Professor";
  private static final String GRADUATED_NAME = "Graduated";
  private static final String STUDENT_NAME = "Student";

  private static final int HEADMASTER_TIME = 1;
  private static final int PROFESSOR_TIME = 3;
  private static final int GRADUATED_TIME = 5;
  private static final int STUDENT_TIME = 7;

  public static final Title HEADMASTER = new Title(HEADMASTER_TIME, HEADMASTER_NAME);
  public static final Title PROFESSOR = new Title(PROFESSOR_TIME, PROFESSOR_NAME);
  public static final Title GRADUATED = new Title(GRADUATED_TIME, GRADUATED_NAME);
  public static final Title STUDENT = new Title(STUDENT_TIME, STUDENT_NAME);

  private final int pauseTime;
  private final String name;

  private Title(int time, String name) {
    this.pauseTime = time;
    this.name = name;
  }

  /**
   * Retourne le temps de pause de ce titre.
   */
  public int getTimeBetweenWords() {
    return this.pauseTime;
  }

  /**
   * Retourne le nom de ce titre.
   */
  public String getName() {
    return this.name;
  }

  // TODO: définir une méthode next()
}
