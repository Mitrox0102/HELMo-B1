package tcg;

import io.Console;
import util.Contract;

public class TCGCardApp {
  private static final int QUIT_ITEM = 5;
  private static final int RESTORE_ITEM = 4;
  private static final int APPLY_DAMAGE_ITEM = 3;
  private static final int ADD_CARD_ITEM = 1;
  private static final int LIST_DECK_ITEM = 2;

  private static final int MP_BAR_SIZE = 5;
  private static final int HP_BAR_SIZE = 10;

  private static final int NOT_ENOUGH_MANA = -1;
  private static final int DECK_CAPACITY = 5;

  public static void main(String[] args) {
    TCGCard[] deck = new TCGCard[DECK_CAPACITY];
    int deckSize = 0;
    boolean quitRequested = false;

    Console.println("POO - Labo 1");
    Console.println("============");
    Console.println();

    while (!quitRequested) {
      printMenu(deckSize);
      int userChoice = readInt("Votre choix ?", 1, 5);
      Console.println();

      switch (userChoice) {
        case ADD_CARD_ITEM -> deckSize = executeAddCardItem(deck, deckSize);
        case LIST_DECK_ITEM -> executeListDeckItem(deck, deckSize);
        case APPLY_DAMAGE_ITEM -> executeApplyDamageItem(deck, deckSize);
        case RESTORE_ITEM -> executeRestoreDeckItem(deck, deckSize);
        case QUIT_ITEM -> quitRequested = true;
      }
    }

    // Ici, quitRequested == true
    Console.printf("Au revoir%n");
  }

  private static void printMenu(int deckSize) {
    Console.printf("1. Ajouter une carte [%d slots disponibles]%n", DECK_CAPACITY - deckSize);
    Console.printf("2. Afficher le deck%n");
    Console.printf("3. Attaquer%n");
    Console.printf("4. Restaurer le deck%n");
    Console.printf("5. Terminer l'exécution%n");
    Console.println();
  }

  public static int executeAddCardItem(TCGCard[] deck, int deckSize) {
    if (deckSize == DECK_CAPACITY) {
      Console.println("Aucun slot disponible");
      return deckSize;
    }

    deck[deckSize] = makeCard();
    Console.printf("Carte %s ajoutée%n", deck[deckSize].getName());
    return deckSize + 1;
  }

  public static void executeListDeckItem(TCGCard[] deck, int deckSize) {
    if (deckSize == 0) {
      Console.println("Ajoutez d'abord une carte");
      return;
    }

    Console.println("-".repeat(75));
    for (int slot = 0; slot < deckSize; ++slot) {
      Console.println(format(deck[slot]));
      Console.println("-".repeat(75));
    }
  }

  public static void executeApplyDamageItem(TCGCard[] deck, int deckSize) {
    if (deckSize == 0) {
      Console.println("Ajoutez d'abord une carte");
      return;
    }

    for (int cardIndex = 0; cardIndex < deckSize; ++cardIndex) {
      Console.printf("%d. %s\t", cardIndex + 1, deck[cardIndex].getName());
    }

    Console.println();
    int attackerIndex = readInt("Carte qui attaque : ", 1, deckSize) - 1;
    int targetIndex = readInt("Carte qui subit : ", 1, deckSize) - 1;
    Console.println();

    int damage = applyDamage(deck[attackerIndex], deck[targetIndex]);
    if (damage == NOT_ENOUGH_MANA) {
      Console.printf("%s n'a plus assez de mana%n", deck[attackerIndex]);
    } else {
      Console.printf("%s attaque %s%n", deck[attackerIndex], deck[targetIndex]);
      Console.printf("%s a subi %d points de dégâts%n", deck[targetIndex], damage);
      if (!deck[targetIndex].isAlive()) {
        Console.printf("%s a perdu la vie%n", deck[targetIndex]);
      }
    }
  }

  public static void executeRestoreDeckItem(TCGCard[] deck, int deckSize) {
    if (deckSize == 0) {
      Console.println("Ajoutez d'abord une carte");
      return;
    }

    int[] result = restore(deck, deckSize);
    Console.printf("%d carte avec leurs HP restaurés%n", result[0]);
    Console.printf("%d carte avec leurs MP restaurés%n", result[1]);
  }


  public static String format(TCGCard card) {
    Contract.require(card != null, "Argument card indéfini");

    // Calculer les rapports et les multiplier par 10 et 5, respectivement
    int hpRatio = HP_BAR_SIZE * card.getHealthPoints() / card.getMaxHealthPoints();
    int mpRatio = MP_BAR_SIZE * card.getManaPoints() / card.getMaxManaPoints();

    String nameLabel = "Carte : %s%n".formatted(card.getName());
    String textLabel = "%s%n".formatted(card.getText());
    // Ajouter deux marqueurs le premier pour ▮ et le second pour ▯
    String hpLabel = "PV : %s%s %d/%d%n".formatted(
        "▮".repeat(hpRatio), // Appel à repeat pour obtenir hpRatio ▮
        "▯".repeat(HP_BAR_SIZE - hpRatio), // Appel à repeat pour obtenir les ▯ complémentaires
        card.getHealthPoints(),
        card.getMaxHealthPoints());
    String mpLabel = "PM : %s%s %d/%d%n".formatted(
        "▮".repeat(mpRatio),
        "▯".repeat(5 - mpRatio),
        card.getManaPoints(),
        card.getMaxManaPoints());
    String attrLabel = "ATK : %d - DEF : %d%n".formatted(card.getAttack(), card.getDefense());

    return nameLabel + textLabel + hpLabel + mpLabel + attrLabel;
  }

  public static TCGCard makeCard() {
    Console.print("Nouvelle carte\n");
    Console.print("-".repeat(14));
    Console.println();

    String name = readNonBlank("Nom :");
    String text = readNonBlank("Texte :");
    int hp = readInt("HP [10; 999] :", 10, 999);
    int mp = readInt("MP [5; 99] :", 5, 99);
    int atk = readInt("ATK [1; 10] :", 1, 10);
    int def = readInt("DEF [1; 10] :", 1, 10);

    return new TCGCard(name, text, hp, mp, atk, def);
  }

  private static String readNonBlank(String message) {
    String value = Console.readLine(message);

    while (value.isBlank()) {
      value = Console.readLine(message);
    }

    return value;
  }

  private static int readInt(String message, int min, int max) {
    int value = Console.readInt(message);

    // Répéter dans deux cas : si value < min ou si value > max
    // while(value < min || value > max)
    while (value < min || value > max) {
      value = Console.readInt(message);
    }

    return value;
  }

  public static int applyDamage(TCGCard attacker, TCGCard target) {
    Contract.require(attacker != null, "Argument attacker indéfini");
    Contract.require(target != null, "Argument target indéfini");

    int manaConsumed = getConsumedMana(attacker);

    if (attacker.getManaPoints() < manaConsumed) {
      return NOT_ENOUGH_MANA;
    }

    int expectedDamage = 4 * attacker.getAttack() - 2 * target.getDefense();
    int actualDamage = Math.clamp(expectedDamage, 0, target.getHealthPoints());

    target.setHealthPoints(target.getHealthPoints() - actualDamage);
    attacker.setManaPoints(attacker.getManaPoints() - manaConsumed);

    return actualDamage;
  }

  public static int[] restore(TCGCard[] deck, int cardsCount) {
    Contract.require(deck != null, "Argument deck indéfini");
    Contract.require(0 <= cardsCount && cardsCount <= deck.length,
        "Argument cardsCount in [0; %d]. Reçu %d".formatted(deck.length, cardsCount));

    int hpCount = 0;
    int mpCount = 0;

    for (int cardIndex = 0; cardIndex < cardsCount; ++cardIndex) {
      TCGCard card = deck[cardIndex];
      if (!card.isAlive()) {
        card.heal();
        ++hpCount;
      }

      int manaConsumed = getConsumedMana(card);
      if (card.getManaPoints() < manaConsumed) {
        card.fillMana();
        ++mpCount;
      }
    }

    return new int[] {
        hpCount, mpCount
    };
  }

  public static int getConsumedMana(TCGCard card) {
    Contract.require(card != null, "Argument card indéfini");

    return Math.max(1, (card.getAttack() + card.getDefense()) / 4);
  }
}
