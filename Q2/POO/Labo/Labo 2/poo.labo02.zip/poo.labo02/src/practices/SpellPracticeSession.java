package practices;

public class SpellPracticeSession {
  private Wizard[] wizards = {
      // TODO : remplir ce tableau avec les sorciers
  };

  private Spell[] spells = {
      // TODO : remplir ce tableau avec les sortilèges
  };

  public String[] getWizardNames() {
    String[] names = new String[0];
    // TODO : créer un tableau avec les noms des sorciers
    return names;
  }

  public String[] getSpellNames() {
    String[] names = new String[0];
    // TODO : créer un tableau avec les noms des sortilèges
    return names;
  }

  public String[] practice(int wizardIndex, int spellIndex) {
    // TODO : lancer le sortilège par le sorcier
    // TODO : vérifier un changement de titre
    // TODO : supprimer éventuellement le sorcier si il devenu directeur
    // TODO : retourner le tableau des notifications
    return new String[0];
  }


}
